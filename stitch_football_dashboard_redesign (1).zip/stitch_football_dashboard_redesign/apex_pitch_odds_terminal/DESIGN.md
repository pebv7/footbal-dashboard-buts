---
name: Apex Pitch & Odds Terminal
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#00b2d0'
  on-tertiary-container: '#003f4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  data-display:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.03em
  data-metric:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: -0.02em
  data-micro:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-md: 1rem
  margin: 1rem
  margin-lg: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

The design system is engineered for professional football syndicates, quant analysts, and serious sports traders who require institutional-grade clarity under high cognitive loads. It bridges the precision of a Bloomberg Terminal with the dynamic kineticism of live elite sport.

The visual style blends **Technical Minimalism** with controlled **Glassmorphic Precision**:
- **Atmosphere**: Deep midnight and pitch-dark canvas allowing live match telemetry, expected goals (xG), and oscillating market odds to command immediate attention.
- **Form Factor**: Dense, spatial-efficient layouts with crisp, laser-sharp boundaries rather than heavy skeuomorphic ornamentation.
- **Tone**: Analytical, authoritative, instantaneous, and composed.
- **Emotional Response**: Complete situational awareness, rapid legibility of volatility, and zero visual friction during high-frequency match events.

## Colors

The palette leverages a deep spectrum of dark slate and carbon surfaces to establish contrast ratios that exceed WCAG AAA standards for micro-data readouts, highlighted by purposeful semantic neon accents.

### Palette Architecture
- **Primary (`#10B981`) - Pitch Emerald**: Represents positive variances, shortening odds, live green states, and "Over" goal/points markets. Paired with deep green fill (`rgba(16, 185, 129, 0.12)`) for volume indicators and probability bars.
- **Secondary (`#F59E0B`) - Kinetic Amber**: Flags market suspensions, match card events (yellow/red alerts), active drift tracking, and high-priority betting opportunities.
- **Tertiary (`#06B6D4`) - Cool Cyan**: Dedicated to away-club telemetry, possession vectors, expected metrics (xG, xA), and historical head-to-head comparisons.
- **Accent Indigo (`#6366F1`)**: Reserved for secondary comparisons, league benchmarking, and neutral model predictions.
- **Destructive/Under (`#EF4444`) - Crimson Out**: Signals negative drift, lengthening odds, and "Under" markets.
- **Neutral Core**:
  - `Canvas Base`: `#0B0F17` (Deepest pitch black)
  - `Card / Surface Default`: `#111827` (Midnight slate)
  - `Surface Elevated / Row Hover`: `#1E293B` (Structured navy slate)
  - `Border / Hairline Grid`: `rgba(148, 163, 184, 0.12)`
  - `Text Primary`: `#F8FAFC`
  - `Text Secondary / Dim`: `#94A3B8`
  - `Text Muted / Timestamp`: `#64748B`

## Typography

The type system pairs **Inter** for clean, immediate textual navigation with **JetBrains Mono** for all operational financial data, match telemetry, live clock timings, decimal/American odds, and distribution metrics.

### Implementation Rules
- **Tabular Numerals**: All instances of numbers, percentages, spreads, and odds must enforce `font-feature-settings: "tnum" 1, "zero" 1` to eliminate column jitter when values tick live.
- **Letter Spacing**: Micro labels (`label-caps`) use positive tracking (+0.08em) and full uppercase styling to maintain sharp legibility at sizes as small as 10px on dark backgrounds.
- **Hierarchy Split**: Match names, player profiles, and market category labels adopt `Inter`. Quant model scores, spread matrices, goal times, and exchange volumes strictly adopt `JetBrains Mono`.

## Layout & Spacing

A compact, information-dense 12-column layout tailored for split-second multi-match monitoring.

### Grid & Breakpoints
- **Desktop (1440px+)**: 12-column dynamic grid. Modular 3-panel split: League & Fixture Navigation (2.5 cols), Main Telemetry & Live Pitch Distribution (6.5 cols), and Instant Bet Slip & Depth Orderbook (3 cols). Gutters: `1rem`, outer margin: `1.5rem`.
- **Laptop / Tablet (768px - 1439px)**: 8-column responsive grid with collapsible navigation drawer. Core telemetry snaps to full canvas width; betting slips dock into an expandable bottom drawer. Gutters: `0.75rem`, margins: `1rem`.
- **Mobile (< 768px)**: 4-column flow with horizontal swipe tabs for match statistics, minute charts, and odds arrays. Gutters: `0.5rem`, margins: `0.75rem`.

### Density Rhythms
- Spacing follows an ultra-tight 4px base scale (`0.25rem`) to maximize viewable data without causing visual fatigue.
- Internal cell gaps in tabular sheets use `space-xs` (4px) to `space-sm` (8px). Structural card separation uses `space-md` (12px).

## Elevation & Depth

Visual depth is achieved through **Tonal Stratification** accented by restrained **Glassmorphic Boundaries**—avoiding muddy drop shadows that compromise dark-mode contrast.

### Elevation Hierarchy
- **Level 0 (Base Canvas - `#0B0F17`)**: Pitch floor; host canvas for full-screen dashboards.
- **Level 1 (Surface Cards - `#111827`)**: Frosted panels featuring a 1px border of `rgba(148, 163, 184, 0.08)` and `backdrop-filter: blur(12px)`. Used for stat panels, distribution charts, and fixture cards.
- **Level 2 (Active/Hover Containers - `#1E293B`)**: Interacted states, live market cards, and expanded rows. Outlined with `rgba(148, 163, 184, 0.2)`.
- **Level 3 (Floating Overlays & Live Betslips - `#161F30`)**: Elevated modals, tooltips, and floating odds drawers. Enhanced with a focused ambient glow: `box-shadow: 0 12px 32px -4px rgba(0, 0, 0, 0.6), 0 0 1px 1px rgba(16, 185, 129, 0.15)`.

### Glowing Accents
- Neon glows are strictly contextual: active selected odds receive a subtle inner glow (`inset 0 0 8px rgba(16, 185, 129, 0.25)`), and sudden goal events pulse via an animated ring stroke rather than full-surface color flashing.

## Shapes

The design system maintains a **Soft Architectural (`1`)** shape language. Tight edge radii reinforce the professional, terminal-grade aesthetic without feeling abrasive or completely brutalist.

### Radius Assignments
- **Base Components (Buttons, Input Fields, Badges, Odds Cells)**: `4px` (`0.25rem`). Maintains structural grid continuity across hundreds of tabular units.
- **Containers & Stat Cards**: `8px` (`0.5rem`). Delivers subtle soft separation between discrete data panels.
- **Floating Modals & Flyout Sheets**: `12px` (`0.75rem`).
- **Pills & Live Indicators**: Full rounded pill (`9999px`) used exclusively for live status chips (`● LIVE 64'`), market state tags, and miniature team form indicators (`W`, `D`, `L`).

## Components

### Buttons & Odds Selectors
- **Odds Action Cells**: Dense rectangular buttons (`4px` radius) containing market selection text and decimal odds (`JetBrains Mono`). Default state: `#1E293B` background with faint border. Selected state: `#10B981` border with subtle emerald glow, odds font highlighted in `#10B981`. Flashing state: brief neon green outline for shortening odds, crimson outline for drifting odds.
- **Primary CTAs**: Pitch Emerald (`#10B981`) solid fill with `#0B0F17` ultra-bold label for immediate execution in bet slips.
- **Secondary Buttons**: Ghost buttons with `#1E293B` surface, `#94A3B8` text, and border hovering to `#F8FAFC`.

### Data Tables & Fixture Rows
- **Zebra & Border Rhythm**: Hairline separator (`rgba(148, 163, 184, 0.08)`) between rows; row height standardizes to 36px for dense views and 48px for expanded views.
- **Hover Feedback**: Row transitions to background `#1E293B` with a 2px vertical neon highlight on the left boundary.
- **Column Alignment**: Match info and team badges left-aligned; all numeric metrics (Possession %, xG, SOT, Odds, Volumes) strictly right-aligned with fixed monospaced character widths.

### Distribution & Minute Charts
- **Goal Minute Heatmaps**: 90-minute segmented progress ribbons divided into 15-minute intervals. Segment backgrounds default to `rgba(30, 41, 59, 0.6)`. Active scoring zones colored with gradient steps from Cyan (`#06B6D4`) to Pitch Emerald (`#10B981`), with height indicating relative scoring frequency.
- **Variance Indicators**: Bipolar deviation bars with center axis (`0`). Positive margins expand rightward in `#10B981`, negative margins expand leftward in `#EF4444`.

### Chips & Badges
- **Live Match Chip**: Background `rgba(16, 185, 129, 0.12)`, text `#10B981`, containing an animated pulsing dot icon (`●`).
- **Market Status Chip**: Compact monospace uppercase badge (`rgba(245, 158, 11, 0.12)` text `#F59E0B`) denoting "VAR REVIEW" or "SUSPENDED".

### Input Fields & Sliders
- **Numeric Stake Fields**: Background `#0B0F17`, 1px border `#334155`, focus state `#10B981`. Features fixed currency prefix on left and quick increment micro-buttons (`+10`, `+50`, `MAX`) integrated directly inside the field right padding.
- **Threshold Sliders (Over/Under lines)**: Minimalist 4px track in `#1E293B` with high-contrast `#10B981` fill and a clean rectangular draggable thumb.

### Cards & Stat Tiles
- **Glassmorphic Stat Cards**: Background `#111827` at 90% opacity, subtle border `#1E293B`. Card headers display uppercase micro labels (`label-caps`) in `#94A3B8`, main metric in bold `data-display` (`#F8FAFC`), and delta sparklines or percentage drift indicators pinned to the bottom edge.